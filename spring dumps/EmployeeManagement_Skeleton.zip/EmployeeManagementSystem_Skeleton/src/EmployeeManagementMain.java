

public class EmployeeManagementMain {

	/**
	 * @param args
	 * @throws EmployeeManagementException
	 */
	public static void main(String[] args)  {
		// TODO Auto-generated method stub



	}

}
