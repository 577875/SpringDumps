/**
 *
 */
package com.cts.employeemanagement.bo;

public class EmployeeManagementBO {



	/**
	 * @param employeeId
	 * @param transferLocation
	 *
	 */

	public void updateEmployeeLocation(int employeeId, String transferLocation)
	{


	}

	/**
	 * @param transferLocation
	 * @return String
	 *
	 */
	public String getTransferEligiblityStatus(String transferLocation)
	{
		return null;


}
}
