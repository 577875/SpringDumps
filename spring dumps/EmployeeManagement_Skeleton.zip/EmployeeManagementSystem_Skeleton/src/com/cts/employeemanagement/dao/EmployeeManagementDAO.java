package com.cts.employeemanagement.dao;

public class EmployeeManagementDAO {



	/**
	 * @param employeeId
	 * @param transferLocation
	*
	 */
	public void updateEmployeeLocation(int employeeId, String transferLocation)
	{

	}

}
