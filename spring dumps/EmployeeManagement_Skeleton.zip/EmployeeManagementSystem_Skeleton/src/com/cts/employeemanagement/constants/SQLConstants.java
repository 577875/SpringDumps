/**
 *
 */
package com.cts.employeemanagement.constants;


public class SQLConstants {



}
