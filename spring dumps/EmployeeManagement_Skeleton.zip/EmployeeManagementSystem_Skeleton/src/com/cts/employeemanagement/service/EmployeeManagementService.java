package com.cts.employeemanagement.service;

public class EmployeeManagementService {



	/**
	 * @param employeeId
	 * @param transferLocation
	 *
	 */
	public void updateEmployeeLocation(int employeeId, String transferLocation)
	{

	}
}
