/**
 *
 */
package com.cts.employeemanagement.config;

public class EmployeeManagementConfig {


}
