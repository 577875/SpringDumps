/**
 *
 */
package com.cts.employeemanagement.exception;

/**
 * @author 448682
 *
 */
public class EmployeeManagementException extends Exception {

	private static final long serialVersionUID = 6129612846468843103L;

	/**
	 * @param message
	 */
	public EmployeeManagementException(String message) {
		super(message);

}
}
